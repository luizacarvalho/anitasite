import { Text, SafeAreaView, StyleSheet } from 'react-native';

// You can import supported modules from npm
import { Card } from 'react-native-paper';

// or any files within the Snack
import Album2 from './components/Album2';

import Album from './components/Album';

export default function App() {
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.paragraph}>
       ANITTA 
      </Text>
      <Card>
        <Album />
        <Album2 />
      </Card>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 10,
    justifyContent: 'center',
    backgroundColor: '#af69cd',
    padding: 8,
  },
  paragraph: {
    margin: 15,
    fontSize: 25,
    color: "#FFF",
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
