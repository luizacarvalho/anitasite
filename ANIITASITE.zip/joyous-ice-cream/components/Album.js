import { Text, View, StyleSheet, Image, Button } from 'react-native';

export default function Album() {
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>
        Look VMA 2023:
      </Text>
      <Image style={styles.logo} source={require('../assets/ANITTA1.webp')} /> 
      <Button
        title="LISTEN NOW"
        onPress={() => Alert.alert('Simple Button pressed')}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#af69cd',
    padding: 24,
  },
  logo: {
    height: 128,
    width: 128,
  },
  paragraph: {
    margin: 15,
    fontSize: 13,
    color: "#FFF",
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
